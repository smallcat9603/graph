# Community Detection using Girvan-Newman Algorithm
Community detection is an important research area in social networks analysis where we are concerned with discovering the structure of the social network. Detecting communities is of great importance in sociology, biology and computer science, disciplines where systems are often represented as graphs.
