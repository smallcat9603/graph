Last Modified: 04 October 2019
PuLP version: 0.2
XtraPuLP version: 0.3

To install, type:

$ ./install

This will make the PuLP and XtraPuLP standalone executables and libraries. It will also copy the libraries and accompanying headers into lib/ and include/, respectively.

For more information on each program specifically, check the local README files in each program's subdirectory

