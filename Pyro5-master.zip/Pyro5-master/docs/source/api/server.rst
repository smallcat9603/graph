:mod:`Pyro5.server` --- Server (daemon) logic
=============================================

.. automodule:: Pyro5.server
    :members:

