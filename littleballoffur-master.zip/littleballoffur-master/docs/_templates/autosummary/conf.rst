.. currentmodule:: {{ module }}

{{ name | underline }}

.. autoclass:: {{ name }}
    :members:
    :undoc-members:
