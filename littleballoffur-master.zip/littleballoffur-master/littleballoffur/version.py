"""Contains the version of Little Ball of Fur."""

__version__ = "2.2.0"
